<?php

/* @var $this yii\web\View */

$this->title = 'Domowe finanse';
?>
<div class="site-index">

    <div class="jumbotron">
        <h1>Domowe finannse</h1>

        <p class="lead">Zyskaj kontrolę nad swoimi finansami, poprzez zarządzanie wydatkami, wpływani i budżetami.</p>

        <p><a class="btn btn-lg btn-success" href="../../frontend/web/index.php?r=site%2Fsignup">Utwórz konto</a></p>
    </div>

    <div class="body-content">

        <div class="row">
            <div class="col-lg-4">
                
                <p><a class="btn btn-default" href="../../backend/web/index.php?r=budzet">Budżet &raquo;</a></p>
            </div>
            <div class="col-lg-4">

                <p><a class="btn btn-default" href="../../backend/web/index.php?r=wydatki">Wydatki &raquo;</a></p>
            </div>
            <div class="col-lg-4">

                <p><a class="btn btn-default" href="../../backend/web/index.php?r=wplywy">Wpływy &raquo;</a></p>
            </div>
        </div>

    </div>
</div>
