<?php

namespace backend\models;

use Yii;

/**
 * This is the model class for table "budzet".
 *
 * @property int $bud_id
 * @property int $id
 * @property string $nazwa_budzetu
 * @property double $limit_bud
 *
 * @property User $id0
 * @property Wplywy[] $wplywies
 * @property Wydatki[] $wydatkis
 */
class Budzet extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'budzet';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['id'], 'required'],
            [['id'], 'integer'],
            [['limit_bud'], 'number'],
            [['nazwa_budzetu'], 'string', 'max' => 80],
            [['id'], 'exist', 'skipOnError' => true, 'targetClass' => User::className(), 'targetAttribute' => ['id' => 'id']],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'bud_id' => 'Budżet',
            'id' => 'Użytkownik',
            'nazwa_budzetu' => 'Nazwa Budżetu',
            'limit_bud' => 'Limit Budżetu',
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getId0()
    {
        return $this->hasOne(User::className(), ['id' => 'id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getWplywies()
    {
        return $this->hasMany(Wplywy::className(), ['bud_id' => 'bud_id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getWydatkis()
    {
        return $this->hasMany(Wydatki::className(), ['bud_id' => 'bud_id']);
    }


}
