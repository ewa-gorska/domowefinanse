<?php

namespace backend\models;

use Yii;

/**
 * This is the model class for table "wplywy".
 *
 * @property int $wplyw_id
 * @property int $id
 * @property string $data_wplywu
 * @property double $kwota_wplywu
 * @property int $bud_id
 *
 * @property User $id0
 * @property Budzet $bud
 */
class Wplywy extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'wplywy';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['id', 'bud_id'], 'required'],
            [['id', 'bud_id'], 'integer'],
            [['data_wplywu'], 'safe'],
            [['kwota_wplywu'], 'number'],
            [['id'], 'exist', 'skipOnError' => true, 'targetClass' => User::className(), 'targetAttribute' => ['id' => 'id']],
            [['bud_id'], 'exist', 'skipOnError' => true, 'targetClass' => Budzet::className(), 'targetAttribute' => ['bud_id' => 'bud_id']],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'wplyw_id' => 'Wplyw ID',
            'id' => 'Użytkownik',
            'data_wplywu' => 'Data Wpływu',
            'kwota_wplywu' => 'Kwota Wpływu',
            'bud_id' => 'Budżet',
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getId0()
    {
        return $this->hasOne(User::className(), ['id' => 'id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getBud()
    {
        return $this->hasOne(Budzet::className(), ['bud_id' => 'bud_id']);
    }
}
