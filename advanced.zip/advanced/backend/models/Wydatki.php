<?php

namespace backend\models;

use Yii;

/**
 * This is the model class for table "wydatki".
 *
 * @property int $wydatek_id
 * @property int $id
 * @property int $kwota_wydatku
 * @property string $data_wydatku
 * @property int $bud_id
 *
 * @property User $id0
 * @property Budzet $bud
 */
class Wydatki extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
public $file;

    public static function tableName()
    {
        return 'wydatki';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['id', 'bud_id'], 'required'],
            [['id', 'kwota_wydatku', 'bud_id'], 'integer'],
            [['data_wydatku'], 'safe'],
            [['file'], 'file'],
            [['rachunek'], 'string'],
            [['id'], 'exist', 'skipOnError' => true, 'targetClass' => User::className(), 'targetAttribute' => ['id' => 'id']],
            [['bud_id'], 'exist', 'skipOnError' => true, 'targetClass' => Budzet::className(), 'targetAttribute' => ['bud_id' => 'bud_id']],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'wydatek_id' => 'Wydatek ID',
            'id' => 'Użytkownik',
            'kwota_wydatku' => 'Kwota Wydatku',
            'data_wydatku' => 'Data Wydatku',
            'bud_id' => 'Budżet',
            'file' => 'Rachunek',
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getId0()
    {
        return $this->hasOne(User::className(), ['id' => 'id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getBud()
    {
        return $this->hasOne(Budzet::className(), ['bud_id' => 'bud_id']);
    }
}
