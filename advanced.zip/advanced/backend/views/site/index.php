<?php

/* @var $this yii\web\View */


$this->title = 'Domowe finanse';
?>
<div class="site-index">


    <div class="body-content">

        <div class="row">
            <div class="col-lg-4">
                
                <p><a class="btn btn-default" href="../../backend/web/index.php?r=budzet">Budżet &raquo;</a></p>
            </div>
            <div class="col-lg-4">

                <p><a class="btn btn-default" href="../../backend/web/index.php?r=wydatki">Wydatki &raquo;</a></p>
            </div>
            <div class="col-lg-4">

                <p><a class="btn btn-default" href="../../backend/web/index.php?r=wplywy">Wpływy &raquo;</a></p>
            </div>
        </div>

    </div>
</div>
