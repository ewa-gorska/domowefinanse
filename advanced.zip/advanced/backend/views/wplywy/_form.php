<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;

/* @var $this yii\web\View */
/* @var $model backend\models\Wplywy */
/* @var $form yii\widgets\ActiveForm */
?>

<div class="wplywy-form">

    <?php $form = ActiveForm::begin(); ?>

    <?= $form->field($model, 'id')->textInput() ?>

    <?= $form->field($model, 'data_wplywu')->textInput() ?>

    <?= $form->field($model, 'kwota_wplywu')->textInput() ?>

    <?= $form->field($model, 'bud_id')->textInput() ?>

    <div class="form-group">
        <?= Html::submitButton('Save', ['class' => 'btn btn-success']) ?>
    </div>

    <?php ActiveForm::end(); ?>

</div>
