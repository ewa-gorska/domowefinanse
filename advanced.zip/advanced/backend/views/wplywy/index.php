<?php

use yii\helpers\Html;
use yii\grid\GridView;


/* @var $this yii\web\View */
/* @var $searchModel backend\models\WplywySearch */
/* @var $dataProvider yii\data\ActiveDataProvider */

$this->title = 'Wpływy';
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="wplywy-index">

    <h1><?= Html::encode($this->title) ?></h1>
    <?php // echo $this->render('_search', ['model' => $searchModel]); ?>

    <p>
        <?= Html::a('Create Wplywy', ['create'], ['class' => 'btn btn-success']) ?>
    </p>

    <?= GridView::widget([
        'dataProvider' => $dataProvider,
        'filterModel' => $searchModel,
        'columns' => [
            ['class' => 'yii\grid\SerialColumn'],

          //  'wplyw_id',
            'id0.username',
            'data_wplywu',
            'kwota_wplywu',
            'bud.nazwa_budzetu',

            ['class' => 'yii\grid\ActionColumn'],
        ],
    ]); ?>
</div>
