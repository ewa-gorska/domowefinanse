<?php

use yii\helpers\Html;


/* @var $this yii\web\View */
/* @var $model backend\models\Wplywy */

$this->title = 'Dodaj Wpływy';
$this->params['breadcrumbs'][] = ['label' => 'Wplywies', 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="wplywy-create">

    <h1><?= Html::encode($this->title) ?></h1>

    <?= $this->render('_form', [
        'model' => $model,
    ]) ?>

</div>
