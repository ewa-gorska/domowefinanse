<?php

use yii\helpers\Html;
use yii\grid\GridView;

/* @var $this yii\web\View */
/* @var $searchModel backend\models\WydatkiSearch */
/* @var $dataProvider yii\data\ActiveDataProvider */

$this->title = 'Wydatki';
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="wydatki-index">

    <h1><?= Html::encode($this->title) ?></h1>
    <?php // echo $this->render('_search', ['model' => $searchModel]); ?>

    <p>
        <?= Html::a('Create Wydatki', ['create'], ['class' => 'btn btn-success']) ?>
    </p>

    <?= GridView::widget([
        'dataProvider' => $dataProvider,
        'filterModel' => $searchModel,
        'columns' => [
            ['class' => 'yii\grid\SerialColumn'],

          //  'wydatek_id',
            'id0.username',
            'kwota_wydatku',
            'data_wydatku',
            'rachunek',
            'bud.nazwa_budzetu',

            ['class' => 'yii\grid\ActionColumn'],
        ],
    ]); ?>
</div>
