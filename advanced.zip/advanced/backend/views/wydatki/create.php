<?php

use yii\helpers\Html;


/* @var $this yii\web\View */
/* @var $model backend\models\Wydatki */

$this->title = 'Dodaj Wydatki';
$this->params['breadcrumbs'][] = ['label' => 'Wydatkis', 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="wydatki-create">

    <h1><?= Html::encode($this->title) ?></h1>

    <?= $this->render('_form', [
        'model' => $model,
    ]) ?>

</div>
