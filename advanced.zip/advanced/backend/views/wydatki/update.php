<?php

use yii\helpers\Html;

/* @var $this yii\web\View */
/* @var $model backend\models\Wydatki */

$this->title = 'Uaktualnij Wydatki:';
$this->params['breadcrumbs'][] = ['label' => 'Wydatkis', 'url' => ['index']];
$this->params['breadcrumbs'][] = ['label' => $model->wydatek_id, 'url' => ['view', 'id' => $model->wydatek_id]];
$this->params['breadcrumbs'][] = 'Update';
?>
<div class="wydatki-update">

    <h1><?= Html::encode($this->title) ?></h1>

    <?= $this->render('_form', [
        'model' => $model,
    ]) ?>

</div>
